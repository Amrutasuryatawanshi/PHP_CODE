<?php
include_once 'connection.php';
try
{

   if(isset($_POST['update']))
    {
       $id=$_POST['id'];
 $name=$_POST['name'];
 $dob=$_POST['dob'];
 $doj=$_POST['doj'];

 $query3=mysqli_query($con, "UPDATE student SET STUDENT_NAME='$name',STUDENT_DOB='$dob',STUDENT_DOJ='$doj' where STUDENT_NO = $id ");
 if ( $query3) 
    {
    echo "<script>alert('You have successfully update   Student...!!!');</script>";
echo "<script >document.location ='Student.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }

}


}
catch(expection $exp)
{
 echo $exp;
} 
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;

}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  max-width: 900px;
  max-height: 900px;
  padding-left:  400px;

  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=date] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
table, th, td {
  border: 1px solid black;
}
input[type=text]:focus, input[type=date]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
<?php
$id=$_GET['id'];
$res=mysqli_query($con,"select * from  student where
 STUDENT_NO= $id ");
$row = mysqli_fetch_array($res);

    
      ?>
<form method="POST" action="Student_update.php">
  <div class="container">
    <h1>  Update  Student  Details</h1>
    
    <hr>

    <label for="email"><b>Name</b></label>
    <input type="text" value="<?php  echo $row['STUDENT_NAME'];?>" name="name" >

    <label for="psw"><b>DOB</b></label>
    <input type="date" value="<?php  echo $row['STUDENT_DOB'];?>" name="dob" id="psw" >

    <label for="psw-repeat"><b>DOJ</b></label>
    <input type="date" value="<?php  echo $row['STUDENT_DOJ'];?>" name="doj" id="psw-repeat" >
     <input type="hidden" value="<?php  echo $row['STUDENT_NO'];?>" name="id" id="psw-repeat" >
    <button type="submit" class="registerbtn" name='update'>Update</button>
     
</form>
</body>

       


</html>
