<?php
include_once 'connection.php';
try
{

   if(isset($_POST['add']))
    {
 $name=$_POST['name'];
 $dob=$_POST['dob'];
 $doj=$_POST['doj'];

 $query3=mysqli_query($con, "insert into student(STUDENT_NAME,STUDENT_DOB,	STUDENT_DOJ	) value( '$name','$dob','$doj')");
 if ( $query3) 
    {
    echo "<script>alert('You have successfully add New  Student...!!!');</script>";
echo "<script >document.location ='Student.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }

}
if(isset($_GET['del']))
    {

 $id=$_GET['id'];

 $query4=mysqli_query($con,"delete from student where STUDENT_NO = $id");
 if ( $query4) 
    {
    echo "<script>alert('You have successfully add New  Student...!!!');</script>";
echo "<script >document.location ='Student.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}

}
catch(expection $exp)
{
 echo $exp;
} 
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;

}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  max-width: 900px;
  max-height: 900px;
  padding-left:  400px;

  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=date] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
table, th, td {
  border: 1px solid black;
}
input[type=text]:focus, input[type=date]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form method="POST" action="Student.php">
  <div class="container">
    <h1> Student Register</h1>

    <hr>

    <label for="email"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" >

    <label for="psw"><b>DOB</b></label>
    <input type="date" placeholder="Enter DOB" name="dob" id="psw" >

    <label for="psw-repeat"><b>DOJ</b></label>
    <input type="date" placeholder="Enter DOJ" name="doj" id="psw-repeat" >
    <button type="submit" class="registerbtn" name='add'>Add</button>
     
</form>
<button type="submit" name="view" class="registerbtn">View</button>
</body>
<?php
   if(isset($_POST['view']))
    {
?>
          <h4> Student Details</h4>
         
            <table class="table " style="border: 30px; border-color:black; height: 100px;
            width: 500px"> 
           
<?php
$ret=mysqli_query($con,"SELECT * FROM student ");
              


    $counter=1;
    if($ret)
{
    if(mysqli_num_rows($ret) > 0)
    {
    echo "<thead>
               <tr><th>Sr.No</th> 
                <th>Name</th>
                 <th>DOB</th>
                <th>DOJ</th>
                 <th>Edit</th>
                  <th>Delete</th>
                </tr> </thead>";
while($row = mysqli_fetch_array($ret))
{
echo "<tr>";

 echo "<td>". $counter++ ."</td>";
 $id=$row['STUDENT_NO'];
echo  "<td>" . $row['STUDENT_NAME'] ."</td>";
echo  "<td>" . $row['STUDENT_DOB'] ."</td>";
echo  "<td>" . $row['STUDENT_DOJ'] ."</td>";
echo "<td><a href='Student_update.php?id=$id'><i class='fa fa-edit' aria-hidden='true'></i</a></td>";

echo "<td><a href='Student.php?del=del&id=$id'><i class='fa fa-remove' aria-hidden='true'></i</a></td>";

              echo "</tr>";

                }



        echo "</table>";
        // Free result set
        mysqli_free_result($ret);
    } else
    {
        echo "No any Time slot add...!!!";
    }
} else
{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}


            }  ?>
          </table>


</html>
