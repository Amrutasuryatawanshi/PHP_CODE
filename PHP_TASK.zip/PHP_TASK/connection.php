<?php
$con=mysqli_connect("localhost", "root", "", "wx2j0z2kNU");
session_start();
if(mysqli_connect_errno())
{
echo "Connection Fail".mysqli_connect_error();
}
?>